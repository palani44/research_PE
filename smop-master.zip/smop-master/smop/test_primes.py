import liboctave
print liboctave.primes(10000)

