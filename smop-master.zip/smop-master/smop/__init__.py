# SMOP compiler -- Simple Matlab/Octave to Python compiler
# Copyright 2011-2018 Victor Leikehman
