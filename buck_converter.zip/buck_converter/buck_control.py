
dt = 1.0e-6 # Sampling time step
carr_freq = 5000.0 # Frequecy in Hz.
# Time period = 200 micro s
carr_slope = 1.0/(1/carr_freq)
# Slope of the carrier waveform is the ratio
# of the magnitude of the carrier and the time
# period of the waveform. T = 1/f

if t_clock >= t1:
    # Code

    # Carier waveform will y = mx + c
    # x - time and c = 0,
    # waveform always starts at 0.

    #carr_signal = carr_slope*t_clock
    carr_signal += carr_slope*dt

    if carr_signal >= 1.0:
        carr_signal = 0.0

    # mod_signal = 0.3
    mod_signal = vreg_duty_ratio

    if mod_signal > carr_signal:
        gate_signal = 1.0
    else:
        gate_signal = 0.0


    t1 += dt

    buck_carr_signal = carr_signal
    buck_gate_signal = gate_signal

    s1_gate_signal = gate_signal
