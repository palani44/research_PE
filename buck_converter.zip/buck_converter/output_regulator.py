# Regulating the output of the buck converter

dt = 1.0e-3
# Proportional gain
kp = 0.01
# Integral gain
ki = 1.0

if t_clock >= t1:

    # Set a desired reference for the output voltage.
    vref = 9.0

    # Error between the desired reference and the output voltage.

    verr = vref - vout

    # PI controller - Proportional Integral controller
    # Proportional component - changes proportionally w.r.t the Error
    vprop = verr*kp

    # Integral component
    # Sum under the curve
    vinteg += verr*dt*ki

    if vinteg > 0.9:
        vinteg = 0.9
    if vinteg < 0.01:
        vinteg = 0.01

    vcontrol = vprop + vinteg

    if vcontrol > 1.0:
        vcontrol = 1.0
    if vcontrol < 0.0:
        vcontrol = 0.0

    t1 += dt

    vreg_error_voltage = verr
    vreg_control_output = vcontrol

    vreg_duty_ratio = vcontrol
