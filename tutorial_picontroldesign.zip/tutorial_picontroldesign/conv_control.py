import math
dt_sample = 100.0e-6

# First tuning
#kp = 0
#ki = 1.0

# Second tuning
#kp = 0
#ki = 1.5

# Third tuning
#kp = 0.01
#ki = 1.5

# Fourth tuning
#kp = 0.005
#ki = 1.5

#Fifth tuning
#kp = 0.001
#ki = 1.5

# Sixth tuning
kp = 0.5*0.001
ki = 0.5*1.5

# Final design
kp = 0.25*0.001
ki = 0.25*1.5

if t_clock>=t1:
    # The block below is in case you want to check
    # how the controller tracks changing references.
    # Change one of the if-else conditions.
    if t_clock>0.4:
        vref = 100.0
    else:
        vref = 100.0
    err = vref - voutput
    err_integ += err*dt_sample
    duty_ratio = kp*err + ki*err_integ

    # This is if you want to run in open-loop
    # Uncomment and change the duty ratio
#    duty_ratio = 0.5

    if duty_ratio>1.0:
        duty_ratio = 1.0
    if duty_ratio<0.0:
        duty_ratio = 0.0

    t1 += dt_sample

convcontrol_dutyratio = duty_ratio
