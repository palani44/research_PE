import math

dt_sample = 5.0e-7
carr_freq = 5000.0

if t_clock>=t1:
    x_saw += carr_freq*dt_sample
    if x_saw>1.0:
        x_saw = 0.0
    
    if convcontrol_dutyratio>x_saw:
        s1gate = 1.0
    else:
        s1gate = 0.0
    
    t1 += dt_sample

mod_check = x_saw
