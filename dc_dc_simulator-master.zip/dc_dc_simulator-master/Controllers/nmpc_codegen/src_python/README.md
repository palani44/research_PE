# Attention
This folder contains python code related to the generation of the library. This is only relevant to developers. If your a user, nothing to see here move along.