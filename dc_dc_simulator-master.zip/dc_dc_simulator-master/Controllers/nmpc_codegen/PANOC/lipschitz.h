#include "../globals/globals.h"
#include <stddef.h>
#include <stdlib.h>

#ifndef LIPSCHITZ_H
#define LIPSCHITZ_H

real_t get_lipschitz(void);

#endif